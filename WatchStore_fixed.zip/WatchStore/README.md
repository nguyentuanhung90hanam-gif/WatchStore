# WatchStore — Java Web MVC/JSP

WatchStore là dự án website thương mại điện tử bán đồng hồ thời trang nam. Giao diện sử dụng phong cách Modern Luxury với màu đen, trắng kem và vàng đồng.

## Công nghệ

- Java 17
- Jakarta Servlet 6
- JSP, JSTL 3 và Expression Language
- Maven WAR
- HTML5, CSS3 và JavaScript thuần
- SQL Server JDBC đã khai báo sẵn để phát triển database sau

## Chạy dự án

1. Mở thư mục `WatchStore` bằng IntelliJ IDEA.
2. Chờ Maven tải dependency trong `pom.xml`.
3. Cấu hình Tomcat 10.1 trở lên.
4. Deploy artifact `WatchStore:war exploded`.
5. Mở `http://localhost:8080/WatchStore/`.

Có thể build thủ công:

```bash
mvn clean package
```

File WAR được tạo tại `target/WatchStore.war`.

## Tài khoản demo

Mật khẩu có thể nhập bất kỳ giá trị nào từ 6 ký tự:

| Vai trò | Email |
|---|---|
| Quản trị viên | `admin@watchstore.vn` |
| Nhân viên bán hàng | `sales@watchstore.vn` |
| Nhân viên kho | `warehouse@watchstore.vn` |
| Khách hàng | `customer@watchstore.vn` |

## Dữ liệu hiện tại

Dự án chưa bắt buộc database. Sản phẩm và đơn hàng đang được cung cấp bởi:

- `MockProductRepository.java`
- `MockDataStore.java`
- Giỏ hàng lưu trong `HttpSession`

Khi phát triển SQL Server, giữ nguyên interface `ProductRepository` và tạo repository mới sử dụng `DBContext.getConnection()`. Controller và JSP không cần thay đổi cấu trúc.

Các biến môi trường database đã hỗ trợ:

```text
WATCHSTORE_DB_URL
WATCHSTORE_DB_USER
WATCHSTORE_DB_PASSWORD
```

## Phân vùng chức năng

- Guest: trang chủ, danh sách và chi tiết sản phẩm, tin tức, voucher, đăng nhập, đăng ký.
- Member/Customer: hồ sơ, địa chỉ, giỏ hàng, thanh toán, đơn hàng, yêu thích, đánh giá và thông báo.
- Sales: dashboard, đơn hàng, khách hàng, đánh giá, vận chuyển, đổi trả và báo cáo.
- Warehouse: phiếu nhập/xuất, tồn kho, kiểm kê, biến thể và cảnh báo.
- Admin: tài khoản, vai trò, phân quyền, danh mục, thương hiệu, sản phẩm, voucher, banner, bài viết, thông báo, thống kê và báo cáo.

## Kiến trúc

```text
Controller → Repository → Model
     ↓
JSP Layout + JSTL/EL
```

Không có truy vấn SQL hoặc Java Scriptlet trong các trang JSP.
