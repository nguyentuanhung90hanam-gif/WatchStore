package com.watchstore.repository;

import com.watchstore.model.Product;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Dữ liệu mẫu dùng khi chưa kết nối database.
 * Kế thừa ProductRepository để tương thích với các Controller đang lấy
 * attribute "productRepository" từ ServletContext.
 */
public class MockProductRepository extends ProductRepository {

    private static final List<Product> PRODUCTS = List.of(
        product(1, "CASIO", "Edifice Sapphire EFR-S108D", "CAS-EFR-108", "3450000", "4290000", "watch-1.png", "BÁN CHẠY", 18, 4.8),
        product(2, "ORIENT", "Bambino Open Heart Classic", "ORI-BAM-210", "6790000", "7990000", "watch-2.png", "-15%", 9, 4.9),
        product(3, "SEIKO", "Prospex Diver Automatic", "SEI-PRO-510", "9890000", "11200000", "watch-3.png", "MỚI", 5, 4.7),
        product(4, "FOSSIL", "Minimalist Mesh Rose Gold", "FOS-MIN-330", "4250000", "4990000", "watch-4.png", "ĐỘC QUYỀN", 22, 4.8),
        product(5, "CITIZEN", "Tsuyosa Automatic Blue", "CIT-TSU-040", "8250000", "9200000", "watch-1.png", "AUTOMATIC", 7, 4.9),
        product(6, "TISSOT", "Le Locle Powermatic 80", "TIS-LEL-080", "16800000", "18500000", "watch-2.png", "CAO CẤP", 3, 5.0),
        product(7, "G-SHOCK", "GA-B2100 Carbon Core", "GSH-GAB-210", "3990000", "4590000", "watch-3.png", "THỂ THAO", 26, 4.8),
        product(8, "FOSSIL", "Machine Chronograph", "FOS-MAC-420", "5190000", "5890000", "watch-4.png", "ƯU ĐÃI", 14, 4.6)
    );

    private static Product product(int id, String brand, String name, String code,
                                   String price, String oldPrice, String image,
                                   String badge, int quantity, double rating) {
        return new Product(
            id, name,
            new BigDecimal(price),
            new BigDecimal(oldPrice),
            quantity, image, name + " chính hãng",
            badge, brand, rating
        );
    }

    @Override
    public List<Product> findAll() {
        return PRODUCTS;
    }

    @Override
    public List<Product> findFeatured() {
        return PRODUCTS.subList(0, Math.min(4, PRODUCTS.size()));
    }

    @Override
    public Product findById(int id) {
        return PRODUCTS.stream()
                .filter(p -> p.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Product> search(String keyword) {
        if (keyword == null || keyword.isBlank()) return PRODUCTS;
        String value = keyword.toLowerCase(Locale.ROOT);
        return PRODUCTS.stream()
                .filter(p -> (p.getName() + " " + p.getBrand())
                        .toLowerCase(Locale.ROOT)
                        .contains(value))
                .toList();
    }

    @Override
    public List<Product> searchByName(String keyword) {
        return search(keyword);
    }
}
