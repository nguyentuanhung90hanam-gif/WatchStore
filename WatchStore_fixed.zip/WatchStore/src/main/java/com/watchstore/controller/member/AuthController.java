package com.watchstore.controller.member;

import com.watchstore.model.User;
import com.watchstore.repository.UserRepository;
import com.watchstore.util.ViewRouter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/auth/*")
public class AuthController extends HttpServlet {
    private UserRepository users;
    @Override public void init(){ users=(UserRepository)getServletContext().getAttribute("userRepository"); }

    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        String path=req.getPathInfo()==null?"/login":req.getPathInfo();
        if("/logout".equals(path)){req.getSession().invalidate();resp.sendRedirect(req.getContextPath()+"/page/home");return;}
        if("/register".equals(path)) ViewRouter.customer(req,resp,"guest/register","Đăng ký tài khoản");
        else ViewRouter.customer(req,resp,"guest/login","Đăng nhập");
    }

    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setCharacterEncoding("UTF-8");
        String path=req.getPathInfo()==null?"/login":req.getPathInfo();
        try{
            if("/register".equals(path)){
                String name=trim(req.getParameter("fullName")),email=trim(req.getParameter("email")).toLowerCase();
                String phone=trim(req.getParameter("phone")),pass=req.getParameter("password"),confirm=req.getParameter("confirmPassword");
                if(name.length()<2 || name.length()>100) throw new IllegalArgumentException("Họ tên phải từ 2 đến 100 ký tự.");
                if(!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) throw new IllegalArgumentException("Email không đúng định dạng.");
                if(!phone.isBlank() && !phone.matches("\\d{9,11}")) throw new IllegalArgumentException("Số điện thoại chỉ được nhập 9-11 chữ số.");
                if(pass==null || pass.length()<6 || pass.length()>100) throw new IllegalArgumentException("Mật khẩu phải từ 6 đến 100 ký tự.");
                if(!pass.equals(confirm)) throw new IllegalArgumentException("Mật khẩu xác nhận không khớp.");
                User u=users.register(name,email,phone,pass);
                req.getSession().setAttribute("user",u);req.getSession().setAttribute("flash","Đăng ký thành công!");
                resp.sendRedirect(req.getContextPath()+"/page/home");return;
            }
            String email=trim(req.getParameter("email")).toLowerCase(),pass=req.getParameter("password");
            User u=users.login(email,pass);
            if(u==null) throw new IllegalArgumentException("Email hoặc mật khẩu không chính xác.");
            req.getSession().setAttribute("user",u);req.getSession().setAttribute("flash","Đăng nhập thành công!");
            switch(u.getRole()){
                case "ADMIN" -> resp.sendRedirect(req.getContextPath()+"/manage/admin/dashboard");
                case "SALES" -> resp.sendRedirect(req.getContextPath()+"/manage/sales/dashboard");
                case "WAREHOUSE" -> resp.sendRedirect(req.getContextPath()+"/manage/warehouse/dashboard");
                default -> resp.sendRedirect(req.getContextPath()+"/page/home");
            }
        }catch(Exception e){
            // Mọi lỗi của đăng nhập phải quay lại đúng trang đăng nhập.
            // Chỉ request /register mới được hiển thị trang đăng ký.
            req.setAttribute("error",message(e));
            if("/register".equals(path)){
                ViewRouter.customer(req,resp,"guest/register","Đăng ký tài khoản");
            }else{
                ViewRouter.customer(req,resp,"guest/login","Đăng nhập");
            }
        }
    }
    private String trim(String v){return v==null?"":v.trim();}
    private String message(Exception e){Throwable t=e;while(t.getCause()!=null)t=t.getCause();return t.getMessage()==null?"Thao tác không thành công.":t.getMessage();}
}
