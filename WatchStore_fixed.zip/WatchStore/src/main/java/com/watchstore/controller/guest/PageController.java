package com.watchstore.controller.guest;

import com.watchstore.model.Product;
import com.watchstore.model.User;
import com.watchstore.repository.ProductRepository;
import com.watchstore.repository.OrderRepository;
import com.watchstore.repository.UserRepository;

import com.watchstore.util.ViewRouter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Map;
import java.util.Collections;

@WebServlet("/page/*")
public class PageController extends HttpServlet {
    private ProductRepository products;
    private OrderRepository orderRepository;
    private UserRepository userRepository;
    private com.watchstore.repository.CartRepository cartRepository;
    private com.watchstore.repository.WishlistRepository wishlistRepository;
    private com.watchstore.repository.AddressRepository addressRepository;

    @Override public void init() { 
        products = (ProductRepository) getServletContext().getAttribute("productRepository"); 
        orderRepository = (OrderRepository) getServletContext().getAttribute("orderRepository");
        userRepository = (UserRepository) getServletContext().getAttribute("userRepository");
        cartRepository = (com.watchstore.repository.CartRepository)getServletContext().getAttribute("cartRepository");
        wishlistRepository = (com.watchstore.repository.WishlistRepository)getServletContext().getAttribute("wishlistRepository");
        addressRepository = (com.watchstore.repository.AddressRepository)getServletContext().getAttribute("addressRepository");
    }

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo() == null ? "/home" : req.getPathInfo();
        User current=(User)req.getSession().getAttribute("user");
        try { req.setAttribute("cartCount", current==null?0:cartRepository.count(current.getId())); } catch(Exception e){req.setAttribute("cartCount",0);}
        req.setAttribute("featuredProducts", products.findFeatured());
        req.setAttribute("products", products.search(req.getParameter("q")));
        req.setAttribute("orders", current==null?Collections.emptyList():orderRepository.findByCustomerId(current.getId()));
        if(current!=null){ try { req.setAttribute("wishlistProducts",wishlistRepository.findAll(current.getId())); req.setAttribute("addresses",addressRepository.findAll(current.getId())); } catch(Exception e){req.setAttribute("wishlistProducts",Collections.emptyList());req.setAttribute("addresses",Collections.emptyList());} }

        Map<String, String[]> pages = Map.ofEntries(
                Map.entry("/home", new String[]{"guest/home", "Trang chủ"}),
                Map.entry("/products", new String[]{"guest/product-list", "Sản phẩm"}),
                Map.entry("/news", new String[]{"guest/news", "Tin tức"}),
                Map.entry("/vouchers", new String[]{"guest/voucher", "Kho voucher"}),
                Map.entry("/profile", new String[]{"member/profile", "Thông tin cá nhân"}),
                Map.entry("/change-password", new String[]{"member/change-password", "Đổi mật khẩu"}),
                Map.entry("/forgot-password", new String[]{"guest/forgot-password", "Quên mật khẩu"}),
                Map.entry("/address", new String[]{"member/address", "Địa chỉ nhận hàng"}),
                Map.entry("/wishlist", new String[]{"customer/wishlist", "Sản phẩm yêu thích"}),
                Map.entry("/reviews", new String[]{"customer/review", "Đánh giá của tôi"}),
                Map.entry("/notifications", new String[]{"customer/notification", "Thông báo"})
        );

        if (path.equals("/product")) {
            int id = parseInt(req.getParameter("id"), 1);
            Product product = products.findById(id);
            if (product == null && !products.findFeatured().isEmpty()) {
                product = products.findFeatured().get(0);
            }
            req.setAttribute("product", product);
            ViewRouter.customer(req, resp, "guest/product-detail", "Chi tiết sản phẩm");
            return;
        }

        String[] page = pages.getOrDefault(path, pages.get("/home"));
        if (isProtected(path) && req.getSession().getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/auth/login?required=1");
            return;
        }
        ViewRouter.customer(req, resp, page[0], page[1]);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String path = req.getPathInfo();
        User user = (User) req.getSession().getAttribute("user");

        if ("/wishlist".equals(path) && user != null) {
            try { wishlistRepository.toggle(user.getId(), Integer.parseInt(req.getParameter("productId"))); req.getSession().setAttribute("flash","Đã cập nhật danh sách yêu thích."); }
            catch(Exception e){ req.getSession().setAttribute("flash", e.getMessage()); }
        } else if ("/profile".equals(path) && user != null) {
            String fullName = req.getParameter("fullName");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");

            if (fullName == null || fullName.trim().length() < 2 || fullName.trim().length() > 100) throw new IllegalArgumentException("Họ tên phải từ 2 đến 100 ký tự.");
            if (phone != null && !phone.isBlank() && !phone.matches("\\d{9,11}")) throw new IllegalArgumentException("Số điện thoại chỉ được nhập 9-11 chữ số.");
            if (address != null && address.length() > 500) throw new IllegalArgumentException("Địa chỉ không được vượt quá 500 ký tự.");
            user.setFullName(fullName.trim());
            if (phone != null) user.setPhone(phone.trim());
            if (address != null) user.setAddress(address.trim());

            if (userRepository != null) {
                userRepository.update(user);
            }
            req.getSession().setAttribute("user", user);
            req.getSession().setAttribute("flash", "Cập nhật thông tin cá nhân thành công!");
        } else if ("/change-password".equals(path) && user != null) {
            String oldPass = req.getParameter("oldPassword");
            String newPass = req.getParameter("newPassword");
            String confirmPass = req.getParameter("confirmPassword");

            if (newPass == null || newPass.length() < 6 || newPass.length() > 100) {
                req.getSession().setAttribute("flash", "Lỗi: Mật khẩu mới phải từ 6 đến 100 ký tự!");
            } else if (newPass == null || !newPass.equals(confirmPass)) {
                req.getSession().setAttribute("flash", "Lỗi: Mật khẩu xác nhận không trùng khớp!");
            } else if (userRepository != null) {
                boolean success = userRepository.updatePassword(user.getId(), oldPass, newPass);
                if (success) {
                    req.getSession().setAttribute("flash", "Đổi mật khẩu thành công!");
                } else {
                    req.getSession().setAttribute("flash", "Lỗi: Mật khẩu hiện tại không chính xác!");
                }
            } else {
                user.setPassword(newPass);
                req.getSession().setAttribute("flash", "Đổi mật khẩu thành công!");
            }
        } else if ("/address".equals(path) && user != null) {
            try {
                String action=req.getParameter("action");
                int id=parseInt(req.getParameter("id"),0);
                if ("delete".equals(action)) {
                    if(id<=0) throw new IllegalArgumentException("Địa chỉ không hợp lệ.");
                    addressRepository.delete(user.getId(),id);
                } else {
                    String name=req.getParameter("name"), phone=req.getParameter("phone"), province=req.getParameter("province"), district=req.getParameter("district"), ward=req.getParameter("ward"), line=req.getParameter("line");
                    if(name==null || name.trim().length()<2 || name.trim().length()>100) throw new IllegalArgumentException("Tên người nhận không hợp lệ.");
                    if(phone==null || !phone.matches("\\d{9,11}")) throw new IllegalArgumentException("Số điện thoại chỉ được nhập 9-11 chữ số.");
                    if(blank(province)||blank(district)||blank(ward)||blank(line)) throw new IllegalArgumentException("Vui lòng nhập đầy đủ địa chỉ.");
                    if(line.trim().length()>300) throw new IllegalArgumentException("Địa chỉ chi tiết quá dài.");
                    addressRepository.save(user.getId(),id==0?null:id,name.trim(),phone.trim(),province.trim(),district.trim(),ward.trim(),line.trim(),req.getParameter("type"),"1".equals(req.getParameter("default"))||"default".equals(action));
                }
                req.getSession().setAttribute("flash","Đã cập nhật địa chỉ.");
            } catch(Exception e){req.getSession().setAttribute("flash",e.getMessage());}
        }

        resp.sendRedirect(req.getContextPath() + "/page" + (path == null ? "/home" : path));
    }

    private boolean blank(String value){return value==null || value.trim().isEmpty();}
    private boolean isProtected(String path) { return path.matches("/(profile|change-password|address|wishlist|reviews|notifications)"); }
    private int parseInt(String value, int fallback) { try { return Integer.parseInt(value); } catch (Exception ignored) { return fallback; } }
}