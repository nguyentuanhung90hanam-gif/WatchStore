package com.watchstore.listener;

import com.watchstore.repository.AddressRepository;
import com.watchstore.repository.CartRepository;
import com.watchstore.repository.MockProductRepository;
import com.watchstore.repository.OrderRepository;
import com.watchstore.repository.UserRepository;
import com.watchstore.repository.WishlistRepository;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class AppBootstrapListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        var context = sce.getServletContext();

        // Dùng dữ liệu mẫu cho sản phẩm để trang web vẫn chạy khi chưa cấu hình DB.
        context.setAttribute("productRepository", new MockProductRepository());

        // Khởi tạo đầy đủ repository mà các Controller sử dụng.
        context.setAttribute("userRepository", new UserRepository());
        context.setAttribute("orderRepository", new OrderRepository());
        context.setAttribute("cartRepository", new CartRepository());
        context.setAttribute("addressRepository", new AddressRepository());
        context.setAttribute("wishlistRepository", new WishlistRepository());

        context.setAttribute("appName", "WatchStore");
    }
}
